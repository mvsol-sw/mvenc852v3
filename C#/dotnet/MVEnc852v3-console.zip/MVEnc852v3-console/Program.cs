﻿using MVSol.Enc852;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVEnc852v3_console
{
    class Program
    {
        static void Main(string[] args)
        {
            const int CH = 1;

            //객체생성
            MVEnc852v3Comm comm = new MVEnc852v3Comm("COM1");

            //포트열기
            if(!comm.Open())
            {
                Console.WriteLine("포트열기 실패");
                comm.Dispose();
                comm = null;

                Console.ReadKey();

                return;
            }

            //버전 가져오기
            Console.WriteLine($"펌웨어버전={comm.GetFirmVersion()}");
            Console.WriteLine($"로직버전={comm.GetLogicVersion()}");

            
            comm.GetTriggerOutputMode(0);
            comm.SetTriggerOutputMode(0, 0);

            comm.GetTriggerPulseWidth(0);
            comm.SetTriggerPulseWidth(0, 30000);

            comm.GetTriggerDelay(0);
            comm.SetTriggerDelay(0, 30000);

            comm.GetEncoderResetValue(0);
            comm.SetEncoderResetValue(0, 50000);


           //디바이스 설정값을 플래시 메모리에 저장
           comm.SaveFlash();
           int x = comm.GetEncoderMultiForAnalog(0);
           comm.SetEncoderMultiForAnalog(0, 300);
           Console.WriteLine($"아날로그 멀티={x}");
           
           int y = comm.GetEncoderAnalogDirection(0);
           comm.SetEncoderAnalogDirection(0, 0);
           Console.WriteLine($"아날로그 엔코더 방향={y}");
           comm.SaveFlash();
           comm.SetStartStopCalibration(0, 0);
           
           
           Console.WriteLine("TriggerControl ■■■■■■■■■■■■■■■■■■■■■■■■■■■");
           TriggerControl control = comm.GetTriggerControl(CH);
           Console.WriteLine($"엔코더 타입={control.EncoderType}");
           Console.WriteLine($"엔코더 채널=CH{control.EncoderChannel}");
           Console.WriteLine($"엔코더 멀티={control.Multi}채배");
           Console.WriteLine($"트리거 출력 피연산자={control.ConditionFactor}");
           Console.WriteLine($"트리거 출력 연산자={control.TriggerOut}");
           Console.WriteLine($"엔코더 방향={control.EncoderDirectionFactor}");
           Console.WriteLine($"트리거 출력구간 방향성={control.TriggerDirectionality}");
           Console.WriteLine($"엔코더 보정여부={control.EncoderCorrection != 0}");
           Console.WriteLine($"트리거 베이스={control.TriggerBase}");
           //구간 내 정방향 출력으로 설정
           control.TriggerDirectionality = TriggerDirectionalityConstants.Positive;
           comm.SetTriggerControl(CH, control);
           
           Console.WriteLine("TriggerGenerator ■■■■■■■■■■■■■■■■■■■■■■■■■■");
           TriggerGenerator generator = comm.GetTriggerGenerator(CH);
           Console.WriteLine($"PulseHigh={generator.PulseHigh}");
           Console.WriteLine($"Cycle={generator.Cycle}");
           //트리거 출력을 설정
           //30pulse 동안 15pulse HIGH가 되도록 설정
           generator.SetData(15, 30);
           comm.SetTriggerGenerator(CH, generator);
           
           comm.SetEncoderResolution(0.1);
           double resolution = comm.GetEncoderResolution();
           Console.WriteLine($"엔코더 분해능={resolution}㎛");
           
           int multi = control.Multi;
           
           //단위변환 count => ㎛
           //분해능 / 채배율 * count = 위치
           //변환함수 ToCount(), ToDistance()
           int startPos = comm.GetTriggerPositionStart(CH);
           int endPos = comm.GetTriggerPositionEnd(CH);
           Console.WriteLine($"시작위치={startPos:N0} | {MVEnc852v3Comm.ToPosition(startPos, resolution, multi):N3}㎛");
           Console.WriteLine($"종료위치={endPos:N0} | {MVEnc852v3Comm.ToPosition(endPos, resolution, multi):N3}㎛");
           //트리거 출력 구간의 10,000㎛ ~ 300,000㎛으로 설정
           comm.SetTriggerPositionStart(CH, MVEnc852v3Comm.ToCount(10000, resolution, multi));
           comm.SetTriggerPositionEnd(CH, 300000, resolution, multi);
           
           
           Console.WriteLine("DI STATE ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■");
           int[] di;
           comm.GetDigitalInputState(out di);
           for (int i = 0; i < di.Length; i++)
           {
               string temp = di[i] != 0 ? "HIGH" : "LOW";
               Console.WriteLine($"DI CH{i}={temp}");
           }
           
           Console.WriteLine("STATUS ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■");
           
           for (int i = 0; i < 7; i++)
           {
               Console.WriteLine($"DI CH{i}={comm.GetDigitalInputCount(i):N0}");
           }
           for (int i = 0; i < 4; i++)
           {
               Console.WriteLine($"Trigger CH{i}={comm.GetTriggerCount(i):N0}");
           }
           for (int i = 0; i < 4; i++)
           {
               int count = comm.GetEncoderPosition(i);
               double position = MVEnc852v3Comm.ToPosition(count, resolution, control.Multi);
               Console.WriteLine($"Encoder Position CH{i}={count:N0} | {position:N3}㎛");
           }
           for (int i = 0; i < 4; i++)
           {
               Console.WriteLine($"Error Count CH{i}={comm.GetErrorCount(i):N0}");
           }
           
           //플래시 메모리에 저장된 디바이스 설정값을 불러옴
           comm.LoadFlash();

            //포트닫기
            comm.Close();

            //인스턴스 해제
            comm.Dispose();
            comm = null;

            Console.ReadKey();
            
        }
    }
}
